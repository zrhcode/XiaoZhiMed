package com.atguigu.java.ai.langchain4j;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j
 * @Filename：ToolsTest
 * @Date：2025/5/3 15:15
 * @Author：zrh
 * @version:
 */

import com.atguigu.java.ai.langchain4j.assistant.SeparateChatAssistant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 *@Description:
 *@className：ToolsTest
 *@Date：2025/5/3 15:15
 *@Author：zrh

 */
@SpringBootTest
public class ToolsTest {
    @Autowired
    private SeparateChatAssistant separateChatAssistant;

    @Test
    public void testCalculatorTools(){
        String answer = separateChatAssistant.chat(2,"1+2等于几，47561289234的平方根是多少？");
        System.out.println(answer);
    }
}
