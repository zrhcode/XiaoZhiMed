package com.atguigu.java.ai.langchain4j;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j
 * @Filename：AIServiceTest
 * @Date：2025/4/24 17:27
 * @Author：zrh
 * @version:
 */

import com.atguigu.java.ai.langchain4j.assistant.Assistant;
import dev.langchain4j.community.model.dashscope.QwenChatModel;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.spring.AiService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

/**
 *@Description:
 *@className：AIServiceTest
 *@Date：2025/4/24 17:27
 *@Author：zrh

 */
@SpringBootTest
public class AIServiceTest {
    @Autowired
    private QwenChatModel qwenChatModel;

    @Test
    public void testChat(){
       Assistant assistant = AiServices.create(Assistant.class,qwenChatModel);
        String answer = assistant.chat("你好呀！");
        System.out.println(answer);
    }

    @Autowired
    private Assistant assistant;
    @Test
    public void testAssiatant(){
        String answer = assistant.chat("你是谁");
        System.out.println(answer);
    }
}
