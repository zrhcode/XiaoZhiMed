package com.atguigu.java.ai.langchain4j.assistant;

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.V;
import dev.langchain4j.service.spring.AiService;

import static dev.langchain4j.service.spring.AiServiceWiringMode.EXPLICIT;

/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.assistant
 * @Filename：SeparateChatAssistant
 * @Date：2025/4/30 22:09
 * @Author：zrh
 * @version:
 */
@AiService(
        wiringMode = EXPLICIT,
        chatModel = "qwenChatModel",
        chatMemoryProvider = "chatMemoryProvider",
        tools = "calculatorTools"
)
public interface SeparateChatAssistant {

//    @SystemMessage("你是我的好朋友，请用四川话回答问题。今天是{{current_date}}")//系统消息提示词
//    @SystemMessage("你是我的好朋友，请用东北话回答问题。")//系统消息提示词
    @SystemMessage(fromResource = "my.prompt.template.txt")//系统消息提示词
    String chat(@MemoryId int memoryId, @UserMessage String userMessage);

    @UserMessage("你是我的好朋友，请用北京话回答问题。{{message}}")//系统消息提示词
    String chat2(@MemoryId int memoryId, @V("message") String userMessage);

    @SystemMessage(fromResource = "my-prompt-template3.txt")
    String chat3(
            @MemoryId int memoryId,
            @UserMessage String userMessage,
            @V("username") String username,
            @V("age") int age
    );
}
