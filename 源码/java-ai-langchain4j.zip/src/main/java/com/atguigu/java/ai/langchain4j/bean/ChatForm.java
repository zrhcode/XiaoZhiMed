package com.atguigu.java.ai.langchain4j.bean;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.bean
 * @Filename：ChatForm
 * @Date：2025/5/3 15:02
 * @Author：zrh
 * @version:
 */

import lombok.Data;

/**
 *@Description:
 *@className：ChatForm
 *@Date：2025/5/3 15:02
 *@Author：zrh

 */
@Data
public class ChatForm {

    private Long memoryId;
    private String message;
}
