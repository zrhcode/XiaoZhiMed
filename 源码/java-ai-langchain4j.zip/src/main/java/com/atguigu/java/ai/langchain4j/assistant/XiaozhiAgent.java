package com.atguigu.java.ai.langchain4j.assistant;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.assistant
 * @Filename：XiaozhiAgent
 * @Date：2025/5/3 14:44
 * @Author：zrh
 * @version:
 */

import dev.langchain4j.service.MemoryId;
import dev.langchain4j.service.SystemMessage;
import dev.langchain4j.service.UserMessage;
import dev.langchain4j.service.spring.AiService;
import reactor.core.publisher.Flux;

import static dev.langchain4j.service.spring.AiServiceWiringMode.EXPLICIT;

/**
 *@Description:
 *@className：XiaozhiAgent
 *@Date：2025/5/3 14:44
 *@Author：zrh

 */
@AiService(
        wiringMode = EXPLICIT,
        /*chatModel = "qwenChatModel",*/
        streamingChatModel = "qwenStreamingChatModel",
        chatMemoryProvider = "chatMemoryProviderXiaozhi",
        tools = "appointmentTools",
        contentRetriever = "contentRetrieverXiaozhiPincone"
)
public interface XiaozhiAgent {

    @SystemMessage(fromResource = "xiaozhi-prompt-template.txt")
//    String chat(@MemoryId Long memoryId, @UserMessage String userMessage);
    Flux<String> chat(@MemoryId Long memoryId, @UserMessage String userMessage);
}
