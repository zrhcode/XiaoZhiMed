package com.atguigu.java.ai.langchain4j.config;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.config
 * @Filename：MemoryChatAssistantConfig
 * @Date：2025/4/30 21:46
 * @Author：zrh
 * @version:
 */

import dev.langchain4j.memory.ChatMemory;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import org.apache.logging.log4j.message.Message;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *@Description:
 *@className：MemoryChatAssistantConfig
 *@Date：2025/4/30 21:46
 *@Author：zrh

 */
@Configuration
public class MemoryChatAssistantConfig {
    @Bean
    public ChatMemory chatMemory(){
        return MessageWindowChatMemory.withMaxMessages(10);
    }
}
