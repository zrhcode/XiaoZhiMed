package com.atguigu.java.ai.langchain4j.bean;
/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.bean
 * @Filename：ChatMessages
 * @Date：2025/5/2 19:51
 * @Author：zrh
 * @version:
 */

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *@Description:
 *@className：ChatMessages
 *@Date：2025/5/2 19:51
 *@Author：zrh

 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Document("chat_messages")
public class ChatMessages {
    //唯一标识符，映射到MongDB文档的_id字段
    @Id
    private ObjectId messageId;

    private String memoryId;


    private String content; //存储当前聊天记录列表的Json字符串
}
