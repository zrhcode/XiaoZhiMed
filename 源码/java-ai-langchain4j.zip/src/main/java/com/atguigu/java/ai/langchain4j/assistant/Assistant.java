package com.atguigu.java.ai.langchain4j.assistant;

import dev.langchain4j.service.spring.AiService;

import static dev.langchain4j.service.spring.AiServiceWiringMode.EXPLICIT;

/**
 * @Project：java-ai-langchain4j
 * @Package：com.atguigu.java.ai.langchain4j.assistant
 * @Filename：Assistant
 * @Date：2025/4/24 17:26
 * @Author：zrh
 * @version:
 */
@AiService(wiringMode = EXPLICIT,
        chatModel = "qwenChatModel")
public interface Assistant {
    String chat(String userMessage);
}
