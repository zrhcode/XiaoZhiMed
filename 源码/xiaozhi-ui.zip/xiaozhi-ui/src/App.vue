<template>
  <ChatWindow/>
</template>

<script setup>
import ChatWindow from '@/components/ChatWindow.vue'
</script>

<style>
html,
body {
  overflow: hidden;
}
</style>
